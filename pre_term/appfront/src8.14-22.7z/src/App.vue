<template>
  <div>
      <router-view></router-view>
  </div>
</template></template>

<script>
  export default {
    name: 'App',
    provide () {
      return {
        reload: this.reload
      }
    }
  }
</script>